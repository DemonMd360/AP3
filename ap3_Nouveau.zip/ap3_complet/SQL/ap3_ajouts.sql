-- ============================================================
-- AP3 - Scripts SQL Server
-- Tables et procédures stockées : Abonnement + Produit (Merch)
-- ============================================================

-- ─── TABLE ABONNEMENT ──────────────────────────────────────────────────────────
CREATE TABLE Abonnement (
    idAbonnement    INT IDENTITY(1,1) PRIMARY KEY,
    idPersonne      INT NOT NULL,
    typeAbonnement  VARCHAR(20) NOT NULL CHECK (typeAbonnement IN ('classique', 'premium')),
    dateDebut       DATE NOT NULL DEFAULT GETDATE(),
    dateFin         DATE NULL,
    estActif        BIT NOT NULL DEFAULT 1,
    FOREIGN KEY (idPersonne) REFERENCES Personne(idPersonne) ON DELETE CASCADE
);
GO

-- ─── TABLE PRODUIT (boutique merch) ───────────────────────────────────────────
CREATE TABLE Produit (
    idProduit   INT IDENTITY(1,1) PRIMARY KEY,
    Nom         VARCHAR(150) NOT NULL,
    Description TEXT         NOT NULL,
    Prix        DECIMAL(8,2) NOT NULL,
    Stock       INT          NOT NULL DEFAULT 0,
    isPremium   BIT          NOT NULL DEFAULT 0  -- 1 = réservé aux abonnés premium
);
GO

-- ============================================================
-- PROCÉDURES STOCKÉES : ABONNEMENT
-- ============================================================

-- Récupérer l'abonnement actif d'une personne
CREATE OR ALTER PROCEDURE GetAbonnementByPersonne
    @idPersonne INT
AS
BEGIN
    SELECT TOP 1
        a.idAbonnement,
        a.idPersonne,
        a.typeAbonnement,
        a.dateDebut,
        a.dateFin,
        a.estActif
    FROM Abonnement a
    WHERE a.idPersonne = @idPersonne
      AND a.estActif   = 1
    ORDER BY a.dateDebut DESC;
END;
GO

-- Souscrire ou changer d'abonnement
-- Désactive l'ancien abonnement, puis crée le nouveau
CREATE OR ALTER PROCEDURE SouscrireAbonnement
    @idPersonne     INT,
    @typeAbonnement VARCHAR(20)
AS
BEGIN
    -- Désactiver l'abonnement actuel s'il existe
    UPDATE Abonnement
    SET estActif = 0, dateFin = GETDATE()
    WHERE idPersonne = @idPersonne AND estActif = 1;

    -- Créer le nouvel abonnement
    INSERT INTO Abonnement (idPersonne, typeAbonnement, dateDebut, estActif)
    VALUES (@idPersonne, @typeAbonnement, GETDATE(), 1);
END;
GO

-- Résilier l'abonnement actif
CREATE OR ALTER PROCEDURE ResilierAbonnement
    @idPersonne INT
AS
BEGIN
    UPDATE Abonnement
    SET estActif = 0, dateFin = GETDATE()
    WHERE idPersonne = @idPersonne AND estActif = 1;
END;
GO

-- ============================================================
-- PROCÉDURES STOCKÉES : PRODUIT (boutique merch)
-- ============================================================

-- Tous les produits
CREATE OR ALTER PROCEDURE GetAllProduits
AS
BEGIN
    SELECT idProduit, Nom, Description, Prix, Stock, isPremium
    FROM Produit
    ORDER BY Nom;
END;
GO

-- Un produit par ID
CREATE OR ALTER PROCEDURE GetProduitById
    @idProduit INT
AS
BEGIN
    SELECT idProduit, Nom, Description, Prix, Stock, isPremium
    FROM Produit
    WHERE idProduit = @idProduit;
END;
GO

-- Produits premium uniquement
CREATE OR ALTER PROCEDURE GetProduitsPremium
AS
BEGIN
    SELECT idProduit, Nom, Description, Prix, Stock, isPremium
    FROM Produit
    WHERE isPremium = 1
    ORDER BY Nom;
END;
GO

-- Créer un produit
CREATE OR ALTER PROCEDURE CreateProduit
    @Nom         VARCHAR(150),
    @Description TEXT,
    @Prix        DECIMAL(8,2),
    @Stock       INT,
    @isPremium   BIT
AS
BEGIN
    INSERT INTO Produit (Nom, Description, Prix, Stock, isPremium)
    VALUES (@Nom, @Description, @Prix, @Stock, @isPremium);

    SELECT SCOPE_IDENTITY() AS NewProduitId;
END;
GO

-- Modifier un produit
CREATE OR ALTER PROCEDURE UpdateProduit
    @idProduit   INT,
    @Nom         VARCHAR(150),
    @Description TEXT,
    @Prix        DECIMAL(8,2),
    @Stock       INT,
    @isPremium   BIT
AS
BEGIN
    UPDATE Produit
    SET
        Nom         = ISNULL(@Nom,         Nom),
        Description = ISNULL(@Description, Description),
        Prix        = ISNULL(@Prix,        Prix),
        Stock       = ISNULL(@Stock,       Stock),
        isPremium   = ISNULL(@isPremium,   isPremium)
    WHERE idProduit = @idProduit;
END;
GO

-- Supprimer un produit
CREATE OR ALTER PROCEDURE DeleteProduit
    @idProduit INT
AS
BEGIN
    DELETE FROM Produit WHERE idProduit = @idProduit;
END;
GO

-- ============================================================
-- DONNÉES DE TEST
-- ============================================================

-- Produits merch de base
INSERT INTO Produit (Nom, Description, Prix, Stock, isPremium) VALUES
('T-Shirt AP3',     'T-shirt officiel AP3, coton bio',         19.99, 100, 0),
('Mug AP3',         'Mug 350ml avec logo AP3',                  9.99, 200, 0),
('Hoodie Premium',  'Sweat à capuche réservé aux membres VIP', 49.99,  50, 1),
('Sticker Pack',    'Pack de 10 stickers AP3',                  4.99, 500, 0),
('Casquette VIP',   'Casquette brodée réservée aux premium',   24.99,  75, 1);
GO
