<?php

namespace App\Models;

use CodeIgniter\Model;

class ProduitModel extends Model
{
    protected $table      = 'Produit';
    protected $primaryKey = 'idProduit';

    protected $allowedFields = [
        'Nom', 'Description', 'Prix', 'Stock', 'isPremium'
    ];

    /**
     * Récupère tous les produits (standard + premium)
     */
    public function getAllProduits()
    {
        return $this->db
            ->query("EXEC GetAllProduits")
            ->getResultArray();
    }

    /**
     * Récupère un produit par son ID
     */
    public function getProduitById($id)
    {
        return $this->db
            ->query("EXEC GetProduitById ?", [$id])
            ->getRowArray();
    }

    /**
     * Récupère uniquement les produits premium
     */
    public function getProduitsPremium()
    {
        return $this->db
            ->query("EXEC GetProduitsPremium")
            ->getResultArray();
    }

    /**
     * Crée un nouveau produit
     */
    public function createProduit($data)
    {
        $this->db->query(
            "EXEC CreateProduit ?, ?, ?, ?, ?",
            [
                $data['Nom'],
                $data['Description'],
                $data['Prix'],
                $data['Stock'],
                $data['isPremium']
            ]
        );
    }

    /**
     * Met à jour un produit
     */
    public function updateProduit($id, $data)
    {
        $this->db->query(
            "EXEC UpdateProduit ?, ?, ?, ?, ?, ?",
            [
                $id,
                $data['Nom']         ?? null,
                $data['Description'] ?? null,
                $data['Prix']        ?? null,
                $data['Stock']       ?? null,
                $data['isPremium']   ?? null
            ]
        );
    }

    /**
     * Supprime un produit
     */
    public function deleteProduit($id)
    {
        $this->db->query("EXEC DeleteProduit ?", [$id]);
    }
}
