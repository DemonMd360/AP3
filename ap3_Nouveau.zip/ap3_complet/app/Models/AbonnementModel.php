<?php

namespace App\Models;

use CodeIgniter\Model;

class AbonnementModel extends Model
{
    protected $table      = 'Abonnement';
    protected $primaryKey = 'idAbonnement';

    protected $allowedFields = [
        'idPersonne', 'typeAbonnement', 'dateDebut', 'dateFin', 'estActif'
    ];

    /**
     * Récupère l'abonnement actif d'une personne
     */
    public function getAbonnementByPersonne($idPersonne)
    {
        return $this->db
            ->query("EXEC GetAbonnementByPersonne ?", [$idPersonne])
            ->getRowArray();
    }

    /**
     * Souscrit ou change l'abonnement d'une personne
     */
    public function souscrireAbonnement($idPersonne, $typeAbonnement)
    {
        $this->db->query(
            "EXEC SouscrireAbonnement ?, ?",
            [$idPersonne, $typeAbonnement]
        );
    }

    /**
     * Résilie l'abonnement actif d'une personne
     */
    public function resilierAbonnement($idPersonne)
    {
        $this->db->query("EXEC ResilierAbonnement ?", [$idPersonne]);
    }
}
