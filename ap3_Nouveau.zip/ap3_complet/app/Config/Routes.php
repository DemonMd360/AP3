<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Page d'accueil
$routes->get('/', 'Home::index');

// ─── AUTH ──────────────────────────────────────────────────────────────────────
$routes->get('auth/login',     'AuthController::loginView');
$routes->get('auth/register',  'AuthController::registerView');
$routes->post('auth/login',    'AuthController::login');
$routes->post('auth/register', 'AuthController::register');
$routes->get('auth/logout',    'AuthController::logout');

// ─── ABONNEMENT (public : liste des types) ─────────────────────────────────────
$routes->get('abonnement/types', 'AbonnementController::types');

// ─── BOUTIQUE (publique : voir les produits) ───────────────────────────────────
$routes->get('boutique',        'BoutiqueController::index');
$routes->get('boutique/(:num)', 'BoutiqueController::show/$1');

// ─── ROUTES PROTÉGÉES PAR JWT (connecté) ──────────────────────────────────────
$routes->group('', ['filter' => 'jwt'], function ($routes) {

    // Profil personnel (CRUD)
    $routes->get('personne/(:num)',          'PersonneController::show/$1');
    $routes->post('personne/edit/(:num)',    'PersonneController::edit/$1');
    $routes->post('personne/delete/(:num)', 'PersonneController::delete/$1');

    // Abonnement
    $routes->get('abonnement/mon-abonnement', 'AbonnementController::monAbonnement');
    $routes->post('abonnement/souscrire',     'AbonnementController::souscrire');
    $routes->post('abonnement/resilier',      'AbonnementController::resilier');

    // Boutique premium
    $routes->get('boutique/premium', 'BoutiqueController::premium');
});

// ─── ROUTES ADMIN (JWT + rôle admin) ──────────────────────────────────────────
$routes->group('admin', ['filter' => 'admin'], function ($routes) {

    // Dashboard
    $routes->get('/',                  'AdminController::index');

    // Gestion utilisateurs
    $routes->get('delete/(:num)',      'AdminController::delete/$1');
    $routes->post('personne/create',   'PersonneController::create');

    // Gestion boutique
    $routes->post('boutique/create',       'BoutiqueController::create');
    $routes->post('boutique/update/(:num)', 'BoutiqueController::update/$1');
    $routes->get('boutique/delete/(:num)', 'BoutiqueController::deleteProduit/$1');
});