<?php

namespace App\Controllers;

use App\Models\ProduitModel;
use App\Models\AbonnementModel;
use CodeIgniter\RESTful\ResourceController;

class BoutiqueController extends ResourceController
{
    /* ============================
       LISTE DES PRODUITS (tous connectés)
    ============================ */
    public function index()
    {
        $model    = new ProduitModel();
        $produits = $model->getAllProduits();

        return $this->respond([
            'status' => 'success',
            'data'   => $produits
        ]);
    }

    /* ============================
       DÉTAIL D'UN PRODUIT
    ============================ */
    public function show($id = null)
    {
        $model   = new ProduitModel();
        $produit = $model->getProduitById($id);

        if (!$produit) {
            return $this->respond(['status' => 'error', 'message' => 'Produit introuvable'], 404);
        }

        return $this->respond([
            'status' => 'success',
            'data'   => $produit
        ]);
    }

    /* ============================
       PRODUITS PREMIUM (abonnés premium uniquement)
    ============================ */
    public function premium()
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded) {
            return $this->respond(['status' => 'error', 'message' => 'Non authentifié'], 401);
        }

        // Vérifier que l'utilisateur a un abonnement premium
        $abonnementModel = new AbonnementModel();
        $abonnement      = $abonnementModel->getAbonnementByPersonne($decoded->uid);

        if (!$abonnement || $abonnement['typeAbonnement'] !== 'premium') {
            return $this->respond([
                'status'  => 'error',
                'message' => 'Accès réservé aux abonnés Premium'
            ], 403);
        }

        $model    = new ProduitModel();
        $produits = $model->getProduitsPremium();

        return $this->respond([
            'status' => 'success',
            'data'   => $produits
        ]);
    }

    /* ============================
       AJOUTER UN PRODUIT (admin uniquement)
    ============================ */
    public function create()
    {
        $decoded = $this->request->user ?? null;

        // idRole 1 = admin
        if (!$decoded || $decoded->role != 1) {
            return $this->respond(['status' => 'error', 'message' => 'Accès admin requis'], 403);
        }

        $json = $this->request->getJSON(true);

        $rules = [
            'Nom'         => 'required',
            'Description' => 'required',
            'Prix'        => 'required|decimal',
            'Stock'       => 'required|integer',
            'isPremium'   => 'required|in_list[0,1]'
        ];

        if (!$this->validateData($json, $rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $model = new ProduitModel();
        $model->createProduit($json);

        return $this->respondCreated([
            'status'  => 'success',
            'message' => 'Produit ajouté avec succès'
        ]);
    }

    /* ============================
       MODIFIER UN PRODUIT (admin uniquement)
    ============================ */
    public function update($id = null)
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded || $decoded->role != 1) {
            return $this->respond(['status' => 'error', 'message' => 'Accès admin requis'], 403);
        }

        $json = $this->request->getJSON(true);

        $model = new ProduitModel();
        $model->updateProduit($id, $json);

        return $this->respond([
            'status'  => 'success',
            'message' => "Produit #$id modifié avec succès"
        ]);
    }

    /* ============================
       SUPPRIMER UN PRODUIT (admin uniquement)
    ============================ */
    public function deleteProduit($id)
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded || $decoded->role != 1) {
            return $this->respond(['status' => 'error', 'message' => 'Accès admin requis'], 403);
        }

        $model = new ProduitModel();
        $model->deleteProduit($id);

        return $this->respond([
            'status'  => 'success',
            'message' => "Produit #$id supprimé"
        ]);
    }
}
