<?php

namespace App\Controllers;

use App\Models\PersonneModel;
use App\Services\JWTService;
use App\Controllers\BaseController;

class AuthController extends BaseController
{
    protected $format = 'json';

    /* ============================
       VUE LOGIN (GET)
    ============================ */
    public function loginView()
    {
        return view('auth/login');
    }

    /* ============================
       VUE REGISTER (GET)
    ============================ */
    public function registerView()
    {
        return view('auth/register');
    }

    /* ============================
       LOGIN (POST)
    ============================ */
    public function login()
    {
        // Accepte aussi bien les formulaires HTML que le JSON
        $json = $this->request->getJSON(true);

        if (!$json) {
            // Fallback formulaire HTML classique
            $json = [
                'Email'      => $this->request->getPost('email') ?? $this->request->getPost('Email'),
                'MotDePasse' => $this->request->getPost('password') ?? $this->request->getPost('MotDePasse'),
            ];
        }

        $rules = [
            'Email'      => 'required|valid_email',
            'MotDePasse' => 'required|min_length[6]'
        ];

        if (!$this->validateData($json, $rules)) {
            return redirect()->to('auth/login')->with('error', implode(', ', $this->validator->getErrors()));
        }

        $userModel = new PersonneModel();
        $user = $userModel->where('Email', $json['Email'])->first();

        if (!$user || !password_verify($json['MotDePasse'], $user['MotDePasse'])) {
            return redirect()->to('auth/login')->with('error', 'Email ou mot de passe incorrect');
        }

        $accessToken  = JWTService::generateToken($user);
        $refreshToken = JWTService::generateRefreshToken($user);

        // Stocker en session pour les vues
        session()->set([
            'isLoggedIn'  => true,
            'idPersonne'  => $user['idPersonne'],
            'Nom'         => $user['Nom'],
            'Prenom'      => $user['Prenom'],
            'Email'       => $user['Email'],
            'idRole'      => $user['idRole'],
            'token'       => $accessToken,
        ]);

        // Si c'est une requête JSON, retourner le token
        if ($this->request->hasHeader('Accept') && strpos($this->request->getHeaderLine('Accept'), 'application/json') !== false) {
            return $this->respond([
                'status'  => 'success',
                'message' => 'Connexion réussie',
                'data'    => [
                    'access_token'  => $accessToken,
                    'refresh_token' => $refreshToken,
                    'token_type'    => 'Bearer',
                    'expires_in'    => 3600,
                    'user' => [
                        'id'     => $user['idPersonne'],
                        'Email'  => $user['Email'],
                        'Nom'    => $user['Nom'],
                        'Prenom' => $user['Prenom'],
                        'idRole' => $user['idRole']
                    ]
                ]
            ]);
        }

        // Redirection selon le rôle
        if ($user['idRole'] == 1) {
            return redirect()->to('admin');
        }

        return redirect()->to('/');
    }

    /* ============================
       REGISTER (POST)
    ============================ */
    public function register()
    {
        $json = $this->request->getJSON(true);

        if (!$json) {
            // Fallback formulaire HTML
            $json = [
                'Nom'        => $this->request->getPost('Nom'),
                'Prenom'     => $this->request->getPost('Prenom'),
                'Email'      => $this->request->getPost('Email'),
                'MotDePasse' => $this->request->getPost('MotDePasse'),
                'Telephone'  => $this->request->getPost('Telephone'),
                'Adresse'    => $this->request->getPost('Adresse'),
            ];
        }

        $rules = [
            'Nom'        => 'required',
            'Prenom'     => 'required',
            'Email'      => 'required|valid_email',
            'MotDePasse' => 'required|min_length[6]',
            'Telephone'  => 'required',
            'Adresse'    => 'required'
        ];

        if (!$this->validateData($json, $rules)) {
            return redirect()->to('auth/register')->with('error', implode(', ', $this->validator->getErrors()));
        }

        $data = [
            'Nom'        => $json['Nom'],
            'Prenom'     => $json['Prenom'],
            'Email'      => $json['Email'],
            'Telephone'  => $json['Telephone'],
            'Adresse'    => $json['Adresse'],
            'MotDePasse' => password_hash($json['MotDePasse'], PASSWORD_DEFAULT),
            'idRole'     => 3  // Rôle "Connecté" par défaut
        ];

        $model = new PersonneModel();
        $model->createPersonne($data);

        return redirect()->to('auth/login')->with('success', 'Compte créé avec succès, connectez-vous !');
    }

    /* ============================
       LOGOUT (GET)
    ============================ */
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}