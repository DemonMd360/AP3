<?php

namespace App\Controllers;

use App\Models\AbonnementModel;
use CodeIgniter\RESTful\ResourceController;

class AbonnementController extends ResourceController
{
    /* ============================
       VOIR SON ABONNEMENT ACTUEL
    ============================ */
    public function monAbonnement()
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded) {
            return $this->respond(['status' => 'error', 'message' => 'Non authentifié'], 401);
        }

        $model       = new AbonnementModel();
        $abonnement  = $model->getAbonnementByPersonne($decoded->uid);

        if (!$abonnement) {
            return $this->respond([
                'status'  => 'success',
                'message' => 'Aucun abonnement actif',
                'data'    => null
            ]);
        }

        return $this->respond([
            'status' => 'success',
            'data'   => $abonnement
        ]);
    }

    /* ============================
       SOUSCRIRE / CHANGER D'ABONNEMENT
    ============================ */
    public function souscrire()
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded) {
            return $this->respond(['status' => 'error', 'message' => 'Non authentifié'], 401);
        }

        $json = $this->request->getJSON(true);

        $rules = [
            'typeAbonnement' => 'required|in_list[classique,premium]'
        ];

        if (!$this->validateData($json, $rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $model = new AbonnementModel();
        $model->souscrireAbonnement($decoded->uid, $json['typeAbonnement']);

        $avantages = $json['typeAbonnement'] === 'premium'
            ? ['Accès boutique merch', 'Réductions exclusives', 'Support prioritaire', 'Contenu premium']
            : ['Accès de base', 'Boutique merch standard'];

        return $this->respondCreated([
            'status'     => 'success',
            'message'    => 'Abonnement ' . $json['typeAbonnement'] . ' activé',
            'avantages'  => $avantages
        ]);
    }

    /* ============================
       RÉSILIER SON ABONNEMENT
    ============================ */
    public function resilier()
    {
        $decoded = $this->request->user ?? null;

        if (!$decoded) {
            return $this->respond(['status' => 'error', 'message' => 'Non authentifié'], 401);
        }

        $model = new AbonnementModel();
        $model->resilierAbonnement($decoded->uid);

        return $this->respond([
            'status'  => 'success',
            'message' => 'Abonnement résilié avec succès'
        ]);
    }

    /* ============================
       LISTE DES TYPES (public)
    ============================ */
    public function types()
    {
        return $this->respond([
            'status' => 'success',
            'data'   => [
                [
                    'type'      => 'classique',
                    'prix'      => 4.99,
                    'avantages' => ['Accès de base', 'Boutique merch standard']
                ],
                [
                    'type'      => 'premium',
                    'prix'      => 9.99,
                    'avantages' => ['Accès boutique merch', 'Réductions exclusives', 'Support prioritaire', 'Contenu premium']
                ]
            ]
        ]);
    }
}
